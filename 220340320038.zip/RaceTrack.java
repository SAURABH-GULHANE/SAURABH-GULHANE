//Que 1
public class RaceTrack{
	public static void main(String[] args){
		Car car = new Car(2010,"Porsche",25.0);
		System.out.println(car.getYear());
		System.out.println(car.getMake());
		System.out.println(car.getSpeed());
		
		car.accelerate();
		System.out.println(car.getSpeed());
	}
}