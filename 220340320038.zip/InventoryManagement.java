
import java.util.ArrayList;
import java.util.Scanner;
class Item{
		int itemId;
		String itemName;
		
		public Item(int itemId, String itemName){
			this.itemId=itemId;
			this.itemName=itemName;			
		}
		public int getitemId(){
			return itemId;
		}
		public String getitemName(){
			return itemName;
		}
		
		public String toString(){
			return "itemId="+itemId+"itemName="+itemName;
		}
}
public class InventoryManagement{
	
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		ArrayList<Item> item = new ArrayList<Item>();
		boolean flag = true;
		while(flag){
		System.out.println("Select the opetions");
		System.out.println("1.Add Item ");
		System.out.println("2.Display all iteams");
		System.out.println("3.Remove Item.");
		System.out.println("4.Exit");
		
		
		
		switch(sc.nextInt()){
			case 1:
				System.out.println("Enter item code and name");
				item.add(new Item(sc.nextInt(),sc.next()));
				// try{
					// //if the item of id is alrady present then it will not get in to the if statement
					// if(item.getitemId()!=item.itemId){
						// item.add(new Item(sc.nextInt(),sc.next()));
					// }
						
				// }catch(Exception e){
					// e.printStackTrace();
				// }
			break;
			
			case 2:
				System.out.println("Element of array list are");
				for (int i=0;i<item.size();i++){
					System.out.println(item.get(i).toString()+" ");
				}
			break;
			
			case 3:
				System.out.println("enter the item id to remove");
				item.remove(sc.nextInt());
			break;
			
			case 4:
				flag = false;
			break;
			
			default:
			break;
		}
		
	}
}
}